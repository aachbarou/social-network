<template>
  <div>
    <h1>Accueil</h1>
    <p>Bienvenue sur le réseau social !</p>
  </div>
</template>

<script>
export default {
  name: 'Home',
};
</script>
