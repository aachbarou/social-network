<template>
  <div>
    <h1>Notifications</h1>
    <p>Liste des notifications.</p>
  </div>
</template>

<script>
export default {
  name: 'Notifications',
};
</script>
