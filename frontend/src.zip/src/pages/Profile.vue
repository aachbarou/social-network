<template>
  <div>
    <h1>Profil</h1>
    <p>Informations du profil utilisateur.</p>
  </div>
</template>

<script>
export default {
  name: 'Profile',
};
</script>
