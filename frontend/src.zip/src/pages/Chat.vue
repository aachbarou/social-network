<template>
  <div>
    <h1>Chat</h1>
    <p>Messagerie instantanée.</p>
  </div>
</template>

<script>
export default {
  name: 'Chat',
};
</script>
