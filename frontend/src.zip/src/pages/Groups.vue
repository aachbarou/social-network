<template>
  <div>
    <h1>Groupes</h1>
    <p>Liste des groupes.</p>
  </div>
</template>

<script>
export default {
  name: 'Groups',
};
</script>
